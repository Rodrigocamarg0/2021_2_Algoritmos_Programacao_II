from Livro import Livro
class No:

    def __init__(self, valor: Livro):
        self.dado = valor
        self.proximo = None